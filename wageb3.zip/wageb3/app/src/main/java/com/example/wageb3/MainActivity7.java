package com.example.wageb3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        final TextView z = findViewById(R.id.textView29);
        final TextView x = findViewById(R.id.textView30);
        final TextView c = findViewById(R.id.textView32);
        final TextView v = findViewById(R.id.textView33);
        final TextView b = findViewById(R.id.textView34);
        final TextView n = findViewById(R.id.textView35);
        final TextView m = findViewById(R.id.textView36);
        final TextView p = findViewById(R.id.textView37);


        Bundle q = getIntent().getExtras();
        String a = q.getString("editTextTextPersonName");
        z.setText(a);
        Bundle w = getIntent().getExtras();
        String f = w.getString("editTextTextPersonName2");
        x.setText(f);
        Bundle g = getIntent().getExtras();
        String k = g.getString("editTextTextPersonName3");
        c.setText(k);
        Bundle u = getIntent().getExtras();
        String o = u.getString("editTextTextPersonName4");
        v.setText(o);
        Bundle s = getIntent().getExtras();
        String d = s.getString("editTextTextPersonName5");
        b.setText(d);
        Bundle y = getIntent().getExtras();
        String l = y.getString("editTextTextPersonName6");
        n.setText(l);
        Bundle e = getIntent().getExtras();
        String ae = e.getString("editTextTextPersonName7");
        m.setText(ae);
        Bundle qw = getIntent().getExtras();
        String ar = qw.getString("editTextTextPersonName8");
        p.setText(ar);
    }
}