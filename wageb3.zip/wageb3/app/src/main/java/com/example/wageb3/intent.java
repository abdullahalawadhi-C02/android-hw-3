package com.example.wageb3;

public class intent {
    public intent(String actionView) {
    }
}
