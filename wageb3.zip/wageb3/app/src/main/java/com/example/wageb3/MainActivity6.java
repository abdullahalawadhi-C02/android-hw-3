package com.example.wageb3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        final Button sumbet = findViewById(R.id.button7);
        final EditText q = findViewById(R.id.editTextTextPersonName);
        final EditText w = findViewById(R.id.editTextTextPersonName2);
        final EditText e = findViewById(R.id.editTextTextPersonName3);
        final EditText t = findViewById(R.id.editTextTextPersonName4);
        final EditText h = findViewById(R.id.editTextTextPersonName5);
        final EditText u = findViewById(R.id.editTextTextPersonName6);
        final EditText i = findViewById(R.id.editTextTextPersonName7);
        final EditText o = findViewById(R.id.editTextTextPersonName8);
        //
        sumbet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity6.this, MainActivity7.class);

                //
                String qInEditText = q.getText().toString();
                String wInEditText = w.getText().toString();
                String eInEditText = e.getText().toString();
                String tInEditText = t.getText().toString();
                String hInEditText = h.getText().toString();
                String uInEditText = u.getText().toString();
                String iInEditText =i.getText().toString();
                String oInEditText = o.getText().toString();
                //
                intent.putExtra("editTextTextPersonName",qInEditText);
                intent.putExtra("editTextTextPersonName2",wInEditText);
                intent.putExtra("editTextTextPersonName3",eInEditText);
                intent.putExtra("editTextTextPersonName4",tInEditText);
                intent.putExtra("editTextTextPersonName5",hInEditText);
                intent.putExtra("editTextTextPersonName6",uInEditText);
                intent.putExtra("editTextTextPersonName7",iInEditText);
                intent.putExtra("editTextTextPersonName8",oInEditText);
                startActivity(intent);
                //
            }
        });
    }
}